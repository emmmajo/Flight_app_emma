package com.example.flight_simulation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FlightResults extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_results);
    }
}